#include <iostream>
#include <list>
using namespace std;

int main(){
	list<string> str;
	str.push_front("Hello");
	str.push_front("Bye");

	list<string>::iterator it;
	for(it = str.begin(); it != str.end(); it++){
		cout << endl << (*it);
	}
}