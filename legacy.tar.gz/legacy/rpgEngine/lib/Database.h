#ifndef DATABASE_H
#define DATABASE_H

using namespace std;
class Datum {
public:
	Datum();
private:
	char* key;	// c-string key
};

class Database {
public:
	
private:
	
};

#endif 
/* DATABASE_H */