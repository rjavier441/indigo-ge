===============
SFML Audio Woes
===============

SFML audio library doesn't support MP3 formats, so the CLI-based tool dir2ogg was acquired via "apt-get install" to convert .mp3 files into .ogg files. Make note of this as you acquire more game music.
