# README #

### What is this repository for? ###

* Summary
    * Indigo: a SFML-based RPG engine
* Version 0.0
    * Currently making an experimental game to learn SFML game dev. 0% progress on the engine itself...
* [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)

### How do I get set up? ###
* Setup
    * Currently only tested/played on Linux
    * Install SFML (I'm using v2.3.2 in Ubuntu Linux). For help, see http://www.sfml-dev.org/tutorials/2.3/
    * Install a C++ compiler (in Linux, I use g++ v4.8.4)
### Contribution guidelines ###

* Writing tests
* Code review
* Other guidelines

### Who do I talk to? ###

* Repo owner or admin
* Other community or team contact