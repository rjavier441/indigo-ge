#include <string>
using namespace std;

class Foo{
public:
	Foo();
	Foo(string);

	string getTitle();
	void setTitle(string);
private:
	string Title;
};