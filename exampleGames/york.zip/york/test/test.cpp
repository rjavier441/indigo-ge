#include <iostream>
#include <list>
#include "foo.h"
using namespace std;

void set(list<Foo>&);

int main(){
	list<Foo> l;

	Foo obj("Object");
	Foo n;

	l.push_front(obj);

	cout << "A.> Front: " << l.front().getTitle() << " Back: " << l.back().getTitle() << endl;

	l.push_front(n);

	cout << "B.> Front: " << l.front().getTitle() << " Back: " << l.back().getTitle() << endl;

	set(l);

	return 0;
}

void set(list<Foo>& w){
	list<Foo> newlist = w;
	Foo myfoo("MyFoo");

	cout << "C.> Front: " << newlist.front().getTitle() << " Back: " << newlist.back().getTitle() << endl << endl;

	newlist.push_front(myfoo);
	for(list<Foo>::iterator it = newlist.begin(); it != newlist.end(); it++){
		cout << (*it).getTitle() << " ";
	}
	cout << endl;
}