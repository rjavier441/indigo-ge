#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <list>
#include <string>
#include <iostream>
using namespace std;

class MenuButton{
public:
	MenuButton(string, string, int, int, int, int);		//constructor with name of button, associated action, left, top, width, and height
	string isClicked(int x, int y);	//checks position of clicks, and returns action if Box was clicked
	string getName();
	int getTop();
	int getLeft();
	int getHeight();
	int getWidth();
private:
	string Name;
	string Action;
	// sf::RectangleShape Box;
	int Top;
	int Left;
	int Height;
	int Width;
};

class Menu{
public:
	Menu(sf::RenderWindow*);	//menu
	Menu(sf::RenderWindow*, string);	//menu with title

	// void Buttons(list<string>&);	//create/replace menu buttons
	// void Title(string);	//change menu title

	// string getTitle();	//get menu title
	// string Click(int x, int y);	//checks to see if a click event's coordinates fall within one of the buttons, and returns the button action of the pressed button
	string Show();	//draw menu and buttons to screen
private:
	list<MenuButton> MenuOptions;
	sf::RenderWindow* Window;
	string Title;	//menu title
};