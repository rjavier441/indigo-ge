#include "World.h"
using namespace std;

/*Class Tile*/
Tile::Tile(string filename){
	File = filename;
}
void Tile::setPosition(int X, int Y){
	Pos.x = X;
	Pos.y = Y;
}
bool Tile::isPassable(){
	return Passable;
}