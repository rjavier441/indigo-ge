#include "foo.h"

Foo::Foo(){
	Title = "Foo";
}

Foo::Foo(string t){
	Title = t;
}

string Foo::getTitle(){
	return Title;
}

void Foo::setTitle(string t){
	Title = t;
}