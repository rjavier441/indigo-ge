#pragma once
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <iostream>
#include <string>
#include <list>
using namespace std;

/*
	World.h: Software to run the world!!! (and generate/load it!)
	Worlds will be divided into three tile levels: Tiles (e.g. ground, floor, grass), Objects (e.g. treasure chests, doors, stairs, diamonds, trees), and Characters (e.g. you, enemies, allies, npcs, store clerks, civilians).

	Movement: Some tiles will allow movement through them, others will not. Characters cannot move passed each other, and Characters cannot pass objects
*/

struct Position {	// Note: struct's methods/vars are public by default!
	int x, y;	//the coordinates of an entity on the world
};

class Tile {
	/*
		A class for a generic tile in the world; an object typically in the flooring of the background. Individual tiles will be 32px by 32px
	*/
public:
	Tile(string, bool = true);	// Takes the filename of the tile texture's source file (must be stored in img/tiles directory). Tiles are assumed to be floor tiles and thus passable by default, but the user can set it otherwise 

	void setPosition(int, int);	// Set the position of the tile in the world

	bool isPassable();	// Returns true if the tile is passable, false otherwise
	Position getPosition();	// Returns the position of the Tile
private:
	string File;	// The filename of the tile texture
	Position Pos;	// The coordinates of the tile in the world
	bool Passable;
};

class Object {
	/*
		A class for objects in the world (anything not a character or tile)
	*/
public:
	Object(string);	// Takes the filename of the object texture's source file (must be stored in img/objects directory)

	void setPosition(int, int);	// Set the position of the object in the world

	bool isSolid();	// Returns false if the object is not solid (i.e. passable), true otherwise
	Position getPosition();	// Returns the position of the object
private:
	string File;	// The filename of the object texture/image
	Position Pos;	// The coordinates of the object in the world
	bool Solid;
};

class Character {
	/*
		A class for generic characters in the world (i.e. parent class of enemies, allies, you, npcs, etc.). Unlike Objects and Tiles, Characters are allowed to move around in the world. Also in contrast, generic Characters can never be passable 
	*/
public:
	Character(string);	// Takes the filename of the character texture's source file

	void setPosition(int, int);	// Set the position of the character in the world
	void move(char k = 's');	// Animates Character movement (i.e. cycles through their movement files). Pass 'u' to move up, 'd' to move down, 'l' to move left, 'r' to move right, or nothing to stay put

	Position getPosition();	// Returns the position of the Character in the world
private:
	string File;
	Position Pos;
};

class World {
public:
	World(sf::RenderWindow*);

	void Load(string);	//load a world specified by the filename string and generate the world texture
	void Show();	//draw the world to the screen

	int getWidth();	//return the world width
	int getHeight(); //return the world height
private:
	sf::View VIEW;
	sf::RenderWindow* WINDOW;
	int width;	//number of tiles wide the world is
	int height;	//number of tiles tall the world is
};