#include "Menu.h"
using namespace std;

/*Class MenuButton*/
MenuButton::MenuButton(string n, string a, int left, int top, int width, int height){
	Name = n;
	Action = a;
	Top = top;
	Left = left;
	Width = width;
	Height = height;
	// Box.setPosition(left, top);
	// Box.setSize(sf::Vector2f(width, height));
}
string MenuButton::isClicked(int x, int y){
	if(Left < x && Width > x && Top < y && Height > y){
		return Action;
	} else {
		return "-";
	}
}
string MenuButton::getName(){
	return Name;
}
int MenuButton::getTop(){
	return Top;
}
int MenuButton::getLeft(){
	return Left;
}
int MenuButton::getWidth(){
	return Width;
}
int MenuButton::getHeight(){
	return Height;
}




/*Class Menu*/
Menu::Menu(sf::RenderWindow* winref){
	Title = "Menu";
}
Menu::Menu(sf::RenderWindow* winref, string t){
	Title = t;
	Window = winref;
}
string Menu::Show(){
	sf::Texture texture;
	if(!texture.loadFromFile("img/menu.png")) return "Error";
	sf::Sprite sprite(texture);
	
	Window->draw(sprite);
	return "Pause";
}














// Menu::Menu(sf::RenderWindow* windowReference){
// 	Title = "Menu";
// 	Window = windowReference;
// }
// Menu::Menu(sf::RenderWindow* windowReference, string t){
// 	Title = t;
// 	Window = windowReference;
// }
// void Menu::Buttons(list<string>& options){
// 	/*Ideally, I'd want only a max of 8 butons, 4 on one side, 4 on the other. Here are the coordinates for the ideally
// 	positioned buttons (in their corresponding positions; coords are in left/top/width/heigth order):

// 	48,502,422,44		550,502,422,44
// 	48,560,422,44		550,560,422,44
// 	48,618,422,44		550,618,422,44
// 	48,676,422,44		550,676,422,44
// 	*/

// 	//Clear buttons if it isn't already empty (useful since it allows Buttons to assign new buttons to an existing menu obj)
// 	if(!MenuOptions.empty()){
// 		MenuOptions.clear();
// 	}

// 	short num = 0;
// 	list<string>::iterator it;
// 	for(it = options.begin(); it != options.end(); it++){
// 		int l,t,w,h;
// 		switch(num){	//8 possible button positions
// 			case 0:{
// 				l = 48;
// 				t = 502;
// 				w = 422;
// 				h = 44;
// 				break;
// 			}
// 			case 1:{
// 				l = 48;
// 				t = 560;
// 				w = 422;
// 				h = 44;
// 				break;
// 			}
// 			case 2:{
// 				l = 48;
// 				t = 618;
// 				w = 422;
// 				h = 44;
// 				break;
// 			}
// 			case 3:{
// 				l = 48;
// 				t = 676;
// 				w = 422;
// 				h = 44;
// 				break;
// 			}
// 			case 4:{
// 				l = 550;
// 				t = 502;
// 				w = 422;
// 				h = 44;
// 				break;
// 			}
// 			case 5:{
// 				l = 550;
// 				t = 560;
// 				w = 422;
// 				h = 44;
// 				break;
// 			}
// 			case 6:{
// 				l = 550;
// 				t = 618;
// 				w = 422;
// 				h = 44;
// 				break;
// 			}
// 			case 7:{
// 				l = 550;
// 				t = 676;
// 				w = 422;
// 				h = 44;
// 				break;
// 			}
// 			default:
// 				break;
// 		}
// 		if(num <= 7){	//makes sure that the menu has no more than 8 buttons
// 			MenuButton button((*it), (*it), l, t, w ,h);
// 			MenuOptions.push_front(button);
// 		}
// 		num++;
// 	}
// }
// void Menu::Title(string t){
// 	Title = t;
// }
// string Menu::getTitle(){
// 	return Title;
// }
// string Menu::Click(int x, int y){
// 	if(MenuOptions.empty()) return "-";

// 	list<MenuButton>::iterator it;
// 	for(it = MenuOptions.begin(); it != MenuOptions.end(); it++){
// 		string result = (*it).isClicked(x,y);	//gets action if button clicked, gets "-" if not
// 		if(result != "-"){
// 			return result;
// 		}
// 	}
// 	return "-";
// }
// string Menu::Show(){
// 	//Load the menu palette (menu background) and create its sprite
// 	sf::Texture palette;
// 	if(!palette.loadFromFile("img/menu.png")){
// 		cout << endl << "Error: menu palette failed to load" << endl;
// 		Window->close();
// 		return "Error";
// 	}
// 	sf::Sprite paletteSprite(palette);

// 	//Create MenuButtons and Draw each individual button
// 	sf::Font menuFont;
// 	if(!menuFont.loadFromFile("fonts/DejaVuSans.ttf")){
// 		cout << endl << "Error: menu font failed to load" << endl;
// 		Window->close();
// 		return "Error";
// 	}
	
// 	//Lay the palette in the background	(don't clear, we want menu over the screen overlay pixels)
// 	Window->draw(paletteSprite);

// 	//Draw each button to the canvas
// 	list<string>::iterator it;
// 	for(it = MenuOptions.begin(); it != MenuOptions.end(); it++){
// 		sf::Text menuText((*it).getName, menuFont, 30);
// 		menuText.setPosition((*it).getLeft(), (*it).getTop());
// 		Window->draw(menuText);
// 	}
// 	Window->display();

// 	//handle events
// 	sf::Event event;
// 	while(Window->pollEvent(event)){
// 		switch(event.type){
// 			case sf::Event::Closed:{
// 				return "Exit";
// 				break;
// 			}
// 			case sf::Event::MouseButtonReleased:{
// 				if(event.mouseButton.button == sf::Mouse::Left){
// 					cout << "[Game] Left mouse button pressed x:" << event.mouseButton.x << " y: " << event.mouseButton.y << endl;
// 					if(this.Click(event.mouseButton.x, event.mouseButton.y) == "Exit"){
// 						return "Quitting";
// 					} else if (this.Click(event.mouseButton.x, event.mouseButton.y) == "Play"){
// 						return "Setup";
// 					}
// 				}
// 				break;
// 			}
// 			case sf::Event::KeyPressed:{

// 				break;
// 			}
// 			default:
// 				break;
// 		}
// 	}
// 	return "";
// }