To Compile and Run game on linux (assuming you have installed g++):

	g++ -c *.h *.cpp
	g++ *.o -o game -lsfml-system -lsfml-window -lsfml-graphics -lsfml-audio
	./game
	