#include "Player.h"
using namespace std;

Player::Player () {
	Name = "???";
	Level = 0;
	Experience = 0;
	MaxHealth = 100;
	Health = 100;
	Armor = 0;
	Magic = 0;
	Attack = 10;
}
Player::Player (string n, int lvl, int xp, int mhp, int hp, int ap, int md, int ad) {
	Name = n;
	Level = lvl;
	Experience = xp;
	MaxHealth = mhp;
	Health = hp;
	Armor = ap;
	Magic = md;
	Attack = ad;
}

Player& Player::setName (string n) {
	Name = n;
	return *this;
}
Player& Player::setImage (string s) {
	Image = s;
	return *this;
}
Player& Player::setLevel (int l) {
	Level = l;
	return *this;
}
Player& Player::setExperience (int x) {
	Experience = x;
	return *this;
}
Player& Player::setMaxHealth (int m) {
	MaxHealth = m;
	return *this;
}
Player& Player::setHP (int h) {
	Health = h;
	return *this;
}
Player& Player::setArmor (int a) {
	Armor = a;
	return *this;
}
Player& Player::setMagic (int m) {
	Magic = m;
	return *this;
}
Player& Player::setAttack (int a) {
	Attack = a;
	return *this;
}

string Player::getName () {
	return Name;
}
string Player::getImage () {
	return Image;
}
int Player::getLevel () {
	return Level;
}
int Player::getExperience () {
	return Experience;
}
int Player::getMaxHealth () {
	return MaxHealth;
}
int Player::getHP () {
	return Health;
}
int Player::getArmor () {
	return Armor;
}
int Player::getMagic () {
	return Magic;
}
int Player::getAttack () {
	return Attack;
}