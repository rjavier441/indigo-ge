#pragma once
#include <iostream>
#include <vector>
#include <string>
using namespace std;

/*  Player.h: A class to define a player's character properties!
	Players will have the basic properties listed below in the private section, including an Inventory and an Image path, which will be used to load a 96x128 pixel image containing all the graphics needed to animate character movement
 */
struct Inventory {
	int gp;		// A character's currency
};

class Player{
public:
	Player();
	Player(string name, int level, int xp, int max_health, int hp, int armor, int magic, int attack_damage);

	Player& setName(string);
	// Player& setImages(vector<string> image_file_paths);
	Player& setImage(string);	// Sets the player's image file name (image must be stored in img/characters)
	Player& setLevel(int);
	Player& setExperience(int);
	Player& setMaxHealth(int);
	Player& setHP(int);
	Player& setArmor(int);
	Player& setMagic(int);
	Player& setAttack(int);
	Player& pickup();	//adds an object to the player's inventory

	string getName();
	string getImage();
	int getLevel();
	int getExperience();
	int getMaxHealth();
	int getHP();
	int getArmor();
	int getMagic();
	int getAttack();
private:
	string Name;
	// vector<string> Images;	// a vector of the 12 images used to animate the player
	string Image;	// A path to the file containing the 12 character images used to animate the player
	int Level;
	int Experience;
	int MaxHealth;
	int Health;
	int Armor;
	int Magic;
	int Attack;
	Inventory Bag;
};