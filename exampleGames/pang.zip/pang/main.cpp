/*
	main.cpp: the file that runs the game (program entry point)

	compilation & linkage terminal command: g++ *.cpp -o game -lsfml-system -lsfml-window -lsfml-graphics -lsfml-audio 
											 ^	  ^	   ^   ^		^				^			^				^
											 1	  2	   3   4		5				6			7				8

	1.>g++ cpp compiler 2.>select all cpp files to compile them to .o files 3.>output to executable 4.>executable name to output to (this will be run with ./game to start the game) 5-8.> libraries to manually link .o files to, in order of dependence (system is first, and all else depend on them. graphics depends on both system and window)

	Bookmark: GameFromScratch.com part
	http://www.gamefromscratch.com/page/Game-From-Scratch-CPP-Edition-Part-3.aspx 
*/

// #include "stdafx.h"	//only need this if using Visual Studio
#include "Game.h"

int main(int argc, char* argv[]){
	Game::Start();

	return 0;
}