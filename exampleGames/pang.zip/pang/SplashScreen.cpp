// #include "StdAfx.h"	//only needed if using Visual Studio
#include "SplashScreen.h"

void SplashScreen::Show(sf::RenderWindow& renderWindow){
	sf::Texture image;

	if(image.loadFromFile("img/1024px-Ping_pong_project.jpg") != true){
		return;
	}

	sf::Sprite sprite(image); //since sprite and window are same size, we need not worry about image coordinates

	renderWindow.draw(sprite);
	renderWindow.display();

	sf::Event event;
	while(true){
		while(renderWindow.pollEvent(event)){
			if(event.type == sf::Event::EventType::KeyPressed || sf::Event::EventType::MouseButtonPressed || sf::Event::EventType::Closed){
				return;
			}
		}
	}
}